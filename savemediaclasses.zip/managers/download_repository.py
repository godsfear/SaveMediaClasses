"""
DownloadRepository — SQLite-слой истории загрузок.

Подписывается на шину событий сам — DownloadManager не знает про базу.
Один экземпляр на всё приложение, создаётся в Services.

Схема таблицы downloads:
  task_id       — UUID задачи (из DownloadManager)
  url           — исходная ссылка
  source        — провайдер ("yt-dlp", "aria2c", ...)
  status        — "running" | "completed" | "failed" | "cancelled"
  started_at    — Unix timestamp начала
  finished_at   — Unix timestamp завершения (NULL пока идёт)
  error_message — текст ошибки (NULL если успех)

  -- полный снимок параметров (DownloadSnapshot) --
  download_path
  proxy_enabled, proxy_address
  cookies_enabled, cookies_browser
  playlist_enabled, embed_metadata
  audio_only, yt_dlp_args
  clean_titles, save_to_source
"""

import sqlite3
import time
from contextlib import contextmanager
from dataclasses import asdict
from typing import Generator, List, Optional

from events import (
    EventBus,
    DownloadStartedEvent,
    DownloadCompletedEvent,
    DownloadCancelledEvent,
)
from managers.download_manager import DownloadSnapshot


# ── Модель записи ─────────────────────────────────────────────────────────────

class DownloadRecord:
    __slots__ = (
        "task_id", "url", "source", "status",
        "started_at", "finished_at", "error_message",
        "download_path", "proxy_enabled", "proxy_address",
        "cookies_enabled", "cookies_browser", "playlist_enabled",
        "embed_metadata", "audio_only", "yt_dlp_args",
        "clean_titles", "save_to_source",
    )

    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)

    def __repr__(self) -> str:
        return f"<DownloadRecord {self.task_id[:8]}… {self.status} {self.url[:40]}>"


# ── Репозиторий ───────────────────────────────────────────────────────────────

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS downloads (
    task_id       TEXT PRIMARY KEY,
    url           TEXT NOT NULL,
    source        TEXT NOT NULL DEFAULT 'yt-dlp',
    status        TEXT NOT NULL DEFAULT 'running',
    started_at    REAL NOT NULL,
    finished_at   REAL,
    error_message TEXT,

    download_path  TEXT,
    proxy_enabled  INTEGER,
    proxy_address  TEXT,
    cookies_enabled INTEGER,
    cookies_browser TEXT,
    playlist_enabled INTEGER,
    embed_metadata  INTEGER,
    audio_only      INTEGER,
    yt_dlp_args     TEXT,
    clean_titles    INTEGER,
    save_to_source  INTEGER
);
"""

_INSERT = """
INSERT OR IGNORE INTO downloads (
    task_id, url, source, status, started_at,
    download_path, proxy_enabled, proxy_address,
    cookies_enabled, cookies_browser, playlist_enabled,
    embed_metadata, audio_only, yt_dlp_args,
    clean_titles, save_to_source
) VALUES (
    :task_id, :url, :source, 'running', :started_at,
    :download_path, :proxy_enabled, :proxy_address,
    :cookies_enabled, :cookies_browser, :playlist_enabled,
    :embed_metadata, :audio_only, :yt_dlp_args,
    :clean_titles, :save_to_source
);
"""

_UPDATE_FINISHED = """
UPDATE downloads
SET status = :status, finished_at = :finished_at, error_message = :error_message
WHERE task_id = :task_id;
"""


class DownloadRepository:

    def __init__(self, db_path: str, bus: EventBus) -> None:
        self._db_path = db_path
        self._bus     = bus
        self._init_db()
        self._subscribe()

    # ── Инициализация ─────────────────────────────────────────────────────────

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(_CREATE_TABLE)

    def _subscribe(self) -> None:
        """Репозиторий сам подписывается на шину — никто снаружи не должен
        заботиться о том, когда и что писать в базу."""
        self._bus.on(DownloadStartedEvent,   self._on_started)
        self._bus.on(DownloadCompletedEvent, self._on_completed)
        self._bus.on(DownloadCancelledEvent, self._on_cancelled)

    # ── Обработчики событий ───────────────────────────────────────────────────

    def _on_started(self, e: DownloadStartedEvent) -> None:
        snap = e.snapshot
        try:
            with self._connect() as conn:
                conn.execute(_INSERT, {
                    "task_id":         e.task_id,
                    "url":             snap.url,
                    "source":          e.source,
                    "started_at":      time.time(),
                    "download_path":   snap.download_path,
                    "proxy_enabled":   int(snap.proxy_enabled),
                    "proxy_address":   snap.proxy_address,
                    "cookies_enabled": int(snap.cookies_enabled),
                    "cookies_browser": snap.cookies_browser,
                    "playlist_enabled": int(snap.playlist_enabled),
                    "embed_metadata":  int(snap.embed_metadata),
                    "audio_only":      int(snap.audio_only),
                    "yt_dlp_args":     snap.yt_dlp_args,
                    "clean_titles":    int(snap.clean_titles),
                    "save_to_source":  int(snap.save_to_source),
                })
        except Exception:
            pass

    def _on_completed(self, e: DownloadCompletedEvent) -> None:
        status = "completed" if e.success else "failed"
        error  = None if e.success else e.message
        self._finish(e.task_id, status, error)

    def _on_cancelled(self, e: DownloadCancelledEvent) -> None:
        self._finish(e.task_id, "cancelled", None)

    def _finish(self, task_id: str, status: str, error: Optional[str]) -> None:
        try:
            with self._connect() as conn:
                conn.execute(_UPDATE_FINISHED, {
                    "task_id":       task_id,
                    "status":        status,
                    "finished_at":   time.time(),
                    "error_message": error,
                })
        except Exception:
            pass

    # ── Публичный API чтения ──────────────────────────────────────────────────

    def get_history(self, limit: int = 100,
                    status: Optional[str] = None) -> List[DownloadRecord]:
        """Последние `limit` записей, опционально отфильтрованных по статусу."""
        query = "SELECT * FROM downloads"
        params: list = []
        if status:
            query += " WHERE status = ?"
            params.append(status)
        query += " ORDER BY started_at DESC LIMIT ?"
        params.append(limit)
        try:
            with self._connect() as conn:
                conn.row_factory = sqlite3.Row
                rows = conn.execute(query, params).fetchall()
                return [DownloadRecord(**dict(r)) for r in rows]
        except Exception:
            return []

    def get_by_url(self, url: str) -> Optional[DownloadRecord]:
        """Последняя запись для данного URL — для дедупликации."""
        try:
            with self._connect() as conn:
                conn.row_factory = sqlite3.Row
                row = conn.execute(
                    "SELECT * FROM downloads WHERE url = ? ORDER BY started_at DESC LIMIT 1",
                    (url,)
                ).fetchone()
                return DownloadRecord(**dict(row)) if row else None
        except Exception:
            return None

    def get_stats(self) -> dict:
        """Агрегированная статистика."""
        try:
            with self._connect() as conn:
                conn.row_factory = sqlite3.Row
                row = conn.execute("""
                    SELECT
                        COUNT(*)                                      AS total,
                        SUM(status = 'completed')                     AS completed,
                        SUM(status = 'failed')                        AS failed,
                        SUM(status = 'cancelled')                     AS cancelled,
                        AVG(CASE WHEN finished_at IS NOT NULL
                            THEN finished_at - started_at END)        AS avg_duration_sec
                    FROM downloads
                """).fetchone()
                return dict(row) if row else {}
        except Exception:
            return {}

    # ── Приватное ─────────────────────────────────────────────────────────────

    @contextmanager
    def _connect(self) -> Generator[sqlite3.Connection, None, None]:
        conn = sqlite3.connect(self._db_path, timeout=5)
        conn.execute("PRAGMA journal_mode=WAL")   # безопасно при параллельных записях
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
